import { Contrast, Sun, Palette } from 'lucide-react';

/**
 * FilterControls Component
 * Renders all filter controls including toggles and sliders
 * 
 * @param {Object} filters - Current filter values
 * @param {Function} onFilterChange - Callback when filter changes
 */
function FilterControls({ filters, onFilterChange }) {
  return (
    <div className="filter-controls">
      {/* Toggle Filters Section */}
      <div className="control-section">
        <h3>
          <Palette size={18} />
          Style Filters
        </h3>
        <div className="toggle-filters">
          <label className="filter-toggle">
            <input
              type="checkbox"
              checked={filters.grayscale}
              onChange={(e) => onFilterChange('grayscale', e.target.checked)}
            />
            <span className="toggle-slider"></span>
            <span className="toggle-label">Grayscale</span>
          </label>

          <label className="filter-toggle">
            <input
              type="checkbox"
              checked={filters.sepia}
              onChange={(e) => onFilterChange('sepia', e.target.checked)}
            />
            <span className="toggle-slider"></span>
            <span className="toggle-label">Sepia</span>
          </label>

          <label className="filter-toggle">
            <input
              type="checkbox"
              checked={filters.invert}
              onChange={(e) => onFilterChange('invert', e.target.checked)}
            />
            <span className="toggle-slider"></span>
            <span className="toggle-label">Invert</span>
          </label>
        </div>
      </div>

      {/* Slider Controls Section */}
      <div className="control-section">
        <h3>
          <Sun size={18} />
          Adjustments
        </h3>
        
        {/* Brightness Slider */}
        <div className="slider-control">
          <div className="slider-header">
            <label>Brightness</label>
            <span className="slider-value">{filters.brightness}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="200"
            value={filters.brightness}
            onChange={(e) => onFilterChange('brightness', parseInt(e.target.value))}
            className="slider brightness-slider"
          />
          <div className="slider-marks">
            <span>Dark</span>
            <span>Normal</span>
            <span>Bright</span>
          </div>
        </div>

        {/* Contrast Slider */}
        <div className="slider-control">
          <div className="slider-header">
            <label>
              <Contrast size={16} />
              Contrast
            </label>
            <span className="slider-value">{filters.contrast}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="200"
            value={filters.contrast}
            onChange={(e) => onFilterChange('contrast', parseInt(e.target.value))}
            className="slider contrast-slider"
          />
          <div className="slider-marks">
            <span>Low</span>
            <span>Normal</span>
            <span>High</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default FilterControls;

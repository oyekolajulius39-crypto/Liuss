import { useState } from 'react';
import { Upload, Image as ImageIcon } from 'lucide-react';

/**
 * ImageUploader Component
 * Handles image upload through drag-and-drop or file selection
 * 
 * @param {Function} onImageUpload - Callback function when image is uploaded
 */
function ImageUploader({ onImageUpload }) {
  const [isDragging, setIsDragging] = useState(false);

  /**
   * Handles drag over event
   */
  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  /**
   * Handles drag leave event
   */
  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragging(false);
  };

  /**
   * Handles file drop
   */
  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);

    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
      onImageUpload(file);
    }
  };

  /**
   * Handles file input change
   */
  const handleFileInput = (e) => {
    const file = e.target.files[0];
    if (file) {
      onImageUpload(file);
    }
  };

  return (
    <div className="uploader-container">
      <div 
        className={`upload-zone ${isDragging ? 'dragging' : ''}`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <div className="upload-content">
          <div className="upload-icon-wrapper">
            <ImageIcon size={64} className="upload-icon" />
            <Upload size={32} className="upload-icon-overlay" />
          </div>
          <h2>Upload Your Photo</h2>
          <p>Drag and drop your image here, or click to browse</p>
          
          <label className="upload-button">
            <input 
              type="file" 
              accept="image/*" 
              onChange={handleFileInput}
              style={{ display: 'none' }}
            />
            Choose File
          </label>

          <div className="upload-hint">
            <p>Supports: JPG, PNG, GIF, WebP</p>
          </div>
        </div>
      </div>

      {/* Feature highlights */}
      <div className="features-grid">
        <div className="feature-card">
          <div className="feature-icon">🎨</div>
          <h3>Apply Filters</h3>
          <p>Choose from multiple artistic filters</p>
        </div>
        <div className="feature-card">
          <div className="feature-icon">⚡</div>
          <h3>Real-time Preview</h3>
          <p>See changes instantly as you adjust</p>
        </div>
        <div className="feature-card">
          <div className="feature-icon">💾</div>
          <h3>Download</h3>
          <p>Save your edited photos in high quality</p>
        </div>
      </div>
    </div>
  );
}

export default ImageUploader;

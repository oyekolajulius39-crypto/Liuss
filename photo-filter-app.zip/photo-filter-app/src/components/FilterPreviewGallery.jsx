import { useEffect, useRef, useState } from 'react';
import { Check } from 'lucide-react';

/**
 * Filter preset configurations
 * Each preset defines a unique combination of filters
 */
const FILTER_PRESETS = [
  {
    name: 'Original',
    filters: {
      grayscale: false,
      sepia: false,
      invert: false,
      brightness: 100,
      contrast: 100,
    }
  },
  {
    name: 'B&W',
    filters: {
      grayscale: true,
      sepia: false,
      invert: false,
      brightness: 100,
      contrast: 110,
    }
  },
  {
    name: 'Vintage',
    filters: {
      grayscale: false,
      sepia: true,
      invert: false,
      brightness: 95,
      contrast: 105,
    }
  },
  {
    name: 'Bright',
    filters: {
      grayscale: false,
      sepia: false,
      invert: false,
      brightness: 140,
      contrast: 110,
    }
  },
  {
    name: 'Dark',
    filters: {
      grayscale: false,
      sepia: false,
      invert: false,
      brightness: 60,
      contrast: 120,
    }
  },
  {
    name: 'Negative',
    filters: {
      grayscale: false,
      sepia: false,
      invert: true,
      brightness: 100,
      contrast: 100,
    }
  },
  {
    name: 'Dramatic',
    filters: {
      grayscale: true,
      sepia: false,
      invert: false,
      brightness: 90,
      contrast: 150,
    }
  },
  {
    name: 'Fade',
    filters: {
      grayscale: false,
      sepia: false,
      invert: false,
      brightness: 110,
      contrast: 80,
    }
  },
];

/**
 * FilterPreviewGallery Component
 * Displays thumbnail previews of all filter presets
 * 
 * @param {string} image - Base64 encoded image
 * @param {Function} onPresetSelect - Callback when preset is selected
 * @param {Object} currentFilters - Currently applied filters
 */
function FilterPreviewGallery({ image, onPresetSelect, currentFilters }) {
  const [previews, setPreviews] = useState([]);

  /**
   * Generate preview thumbnails for each preset
   */
  useEffect(() => {
    if (!image) return;

    const generatePreviews = async () => {
      const img = new Image();
      img.src = image;

      img.onload = () => {
        const previewsData = FILTER_PRESETS.map(preset => {
          // Create a small canvas for thumbnail
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          
          // Thumbnail size
          const size = 120;
          canvas.width = size;
          canvas.height = size;

          // Calculate crop dimensions to maintain aspect ratio
          const scale = Math.max(size / img.width, size / img.height);
          const scaledWidth = img.width * scale;
          const scaledHeight = img.height * scale;
          const x = (size - scaledWidth) / 2;
          const y = (size - scaledHeight) / 2;

          // Build filter string
          let filterString = '';
          if (preset.filters.grayscale) filterString += 'grayscale(100%) ';
          if (preset.filters.sepia) filterString += 'sepia(100%) ';
          if (preset.filters.invert) filterString += 'invert(100%) ';
          filterString += `brightness(${preset.filters.brightness}%) `;
          filterString += `contrast(${preset.filters.contrast}%) `;

          ctx.filter = filterString;
          ctx.drawImage(img, x, y, scaledWidth, scaledHeight);

          return {
            name: preset.name,
            dataUrl: canvas.toDataURL(),
            filters: preset.filters
          };
        });

        setPreviews(previewsData);
      };
    };

    generatePreviews();
  }, [image]);

  /**
   * Check if a preset is currently active
   */
  const isActivePreset = (presetFilters) => {
    return JSON.stringify(presetFilters) === JSON.stringify(currentFilters);
  };

  return (
    <div className="preview-gallery-grid">
      {previews.map((preview, index) => (
        <div 
          key={index}
          className={`preview-card ${isActivePreset(preview.filters) ? 'active' : ''}`}
          onClick={() => onPresetSelect(preview.filters)}
        >
          <div className="preview-image-wrapper">
            <img 
              src={preview.dataUrl} 
              alt={preview.name}
              className="preview-image"
            />
            {isActivePreset(preview.filters) && (
              <div className="active-indicator">
                <Check size={16} />
              </div>
            )}
          </div>
          <div className="preview-label">{preview.name}</div>
        </div>
      ))}
    </div>
  );
}

export default FilterPreviewGallery;

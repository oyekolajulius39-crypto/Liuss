import { useEffect, useRef } from 'react';

/**
 * FilteredImage Component
 * Renders the image with applied filters using HTML5 Canvas
 * 
 * @param {string} image - Base64 encoded image data
 * @param {Object} filters - Filter values to apply
 * @param {React.RefObject} canvasRef - Reference to the canvas element
 */
function FilteredImage({ image, filters, canvasRef }) {
  const containerRef = useRef(null);

  /**
   * Applies filters to the image and draws it on canvas
   */
  useEffect(() => {
    if (!image || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const img = new Image();

    img.onload = () => {
      // Set canvas dimensions to match image
      const container = containerRef.current;
      const maxWidth = container?.clientWidth || 800;
      const maxHeight = container?.clientHeight || 600;

      // Calculate scaled dimensions while maintaining aspect ratio
      let width = img.width;
      let height = img.height;
      const aspectRatio = width / height;

      if (width > maxWidth) {
        width = maxWidth;
        height = width / aspectRatio;
      }

      if (height > maxHeight) {
        height = maxHeight;
        width = height * aspectRatio;
      }

      canvas.width = width;
      canvas.height = height;

      // Build CSS filter string from filter values
      let filterString = '';

      if (filters.grayscale) {
        filterString += 'grayscale(100%) ';
      }

      if (filters.sepia) {
        filterString += 'sepia(100%) ';
      }

      if (filters.invert) {
        filterString += 'invert(100%) ';
      }

      // Brightness: 100 = normal, 0 = black, 200 = very bright
      filterString += `brightness(${filters.brightness}%) `;

      // Contrast: 100 = normal, 0 = gray, 200 = high contrast
      filterString += `contrast(${filters.contrast}%) `;

      // Apply filters to canvas context
      ctx.filter = filterString;

      // Clear canvas and draw image
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, width, height);
    };

    img.src = image;
  }, [image, filters, canvasRef]);

  return (
    <div className="filtered-image-container" ref={containerRef}>
      <canvas 
        ref={canvasRef} 
        className="filtered-canvas"
      />
    </div>
  );
}

export default FilteredImage;

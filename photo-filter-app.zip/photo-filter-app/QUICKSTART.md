# 🚀 Quick Start Guide - Photo Filter Studio

Get your Photo Filter App running in under 5 minutes!

## 📋 Prerequisites Check

Before you begin, make sure you have:

```bash
# Check Node.js version (need 16 or higher)
node --version

# Check npm version
npm --version
```

If you don't have Node.js, download it from [nodejs.org](https://nodejs.org/)

## 🎯 Step-by-Step Setup

### Step 1: Open Terminal/Command Prompt

- **Windows**: Press `Win + R`, type `cmd`, press Enter
- **Mac**: Press `Cmd + Space`, type `terminal`, press Enter
- **Linux**: Press `Ctrl + Alt + T`

### Step 2: Navigate to Project Folder

```bash
# Go to where you downloaded/extracted the project
cd path/to/photo-filter-app

# Example on Windows:
# cd C:\Users\YourName\Downloads\photo-filter-app

# Example on Mac/Linux:
# cd ~/Downloads/photo-filter-app
```

### Step 3: Install Dependencies

```bash
npm install
```

⏱️ This will take 1-2 minutes. You'll see a progress bar.

### Step 4: Start the Development Server

```bash
npm run dev
```

✅ You should see:

```
  VITE v5.0.8  ready in 500 ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: use --host to expose
```

### Step 5: Open in Browser

1. Hold `Ctrl` (or `Cmd` on Mac) and click the `http://localhost:5173/` link
2. Or manually open your browser and go to `http://localhost:5173/`

🎉 **That's it! Your app is now running!**

## 🎨 Try It Out

### Test with Sample Images

1. Click on "Choose File" or drag any image
2. Or use the sample images in `public/sample-images/`:
   - `sample1.svg` - Mountain landscape
   - `sample2.svg` - Tropical beach
   - `sample3.svg` - City night

### Apply Filters

1. Toggle on **Grayscale**, **Sepia**, or **Invert**
2. Move the **Brightness** and **Contrast** sliders
3. Click any preset in the **Quick Presets** gallery
4. Hold **"Hold to Compare"** to see before/after
5. Click **"Download Image"** to save

## 🛑 Stop the Server

To stop the development server:

- Press `Ctrl + C` in the terminal
- Type `Y` when prompted (Windows)

## 🚀 Build for Production

When you're ready to deploy:

```bash
# Create production build
npm run build

# Preview the production build
npm run preview
```

Your optimized app will be in the `dist/` folder.

## 📤 Deploy to Vercel (Free!)

### Option 1: Vercel CLI (Fastest)

```bash
# Install Vercel CLI globally
npm install -g vercel

# Deploy (follow the prompts)
vercel
```

### Option 2: Vercel Dashboard

1. Push your code to GitHub
2. Go to [vercel.com/new](https://vercel.com/new)
3. Import your repository
4. Click "Deploy"
5. Done! You'll get a live URL

## ❓ Common Issues

### "npm: command not found"

**Solution**: Install Node.js from [nodejs.org](https://nodejs.org/)

### "Port 5173 is already in use"

**Solution**: 
```bash
# Kill the process using the port (Windows)
npx kill-port 5173

# Or use a different port
npm run dev -- --port 3000
```

### "Module not found" errors

**Solution**: Delete `node_modules` and reinstall:
```bash
rm -rf node_modules
npm install
```

### App doesn't load in browser

**Solution**:
1. Check terminal for errors
2. Make sure you're at `http://localhost:5173/` (not https)
3. Try a different browser
4. Clear browser cache

## 💡 Pro Tips

1. **Keep terminal open** while developing - you'll see live error messages
2. **Use sample images** first to test all features
3. **Try different browsers** for compatibility testing
4. **Bookmark localhost:5173** for quick access during development

## 📚 Next Steps

Once everything is working:

1. Read the full [README.md](README.md) for detailed documentation
2. Customize colors in `src/App.css`
3. Add new filter presets in `src/components/FilterPreviewGallery.jsx`
4. Share your deployed app with friends!

## 🆘 Need Help?

- Check the main [README.md](README.md) for troubleshooting
- Look for errors in the browser console (F12)
- Check the terminal for error messages

---

**Happy Filtering! 🎨✨**

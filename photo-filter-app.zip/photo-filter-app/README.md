# 🎨 Photo Filter Studio

A modern, feature-rich photo filtering web application built with React 18. Apply professional filters, adjust brightness and contrast in real-time, and download your edited photos instantly.

![Photo Filter Studio](https://img.shields.io/badge/React-18.2-blue) ![Vite](https://img.shields.io/badge/Vite-5.0-purple) ![License](https://img.shields.io/badge/license-MIT-green)

## ✨ Features

- 🖼️ **Drag & Drop Upload** - Easy image uploading with visual feedback
- 🎨 **Multiple Filters**
  - Grayscale - Classic black and white conversion
  - Sepia - Vintage warm tone effect
  - Invert - Negative image effect
  - Brightness - Adjustable from dark to bright (0-200%)
  - Contrast - Adjustable contrast levels (0-200%)
- ⚡ **Real-time Preview** - See changes instantly as you adjust
- 🔄 **Before/After Toggle** - Compare original and filtered images
- 🖼️ **Filter Gallery** - Quick preset previews for instant selection
- 💾 **Download** - Export filtered images as high-quality PNG
- 🌓 **Light/Dark Theme** - Toggle between themes
- 📱 **Responsive Design** - Works perfectly on all devices
- 🎯 **Modern UI** - Clean, professional interface with smooth animations

## 🚀 Quick Start

### Prerequisites

- Node.js 16+ and npm installed on your system

### Installation

1. **Clone or download this project**

2. **Navigate to the project directory**
   ```bash
   cd photo-filter-app
   ```

3. **Install dependencies**
   ```bash
   npm install
   ```

4. **Start the development server**
   ```bash
   npm run dev
   ```

5. **Open your browser**
   - The app will automatically open at `http://localhost:5173`
   - Or manually navigate to the URL shown in your terminal

### Building for Production

```bash
npm run build
```

The optimized production build will be in the `dist/` folder.

## 📦 Project Structure

```
photo-filter-app/
├── public/
│   └── sample-images/          # Sample images for testing
│       ├── sample1.svg         # Mountain landscape
│       ├── sample2.svg         # Tropical beach
│       └── sample3.svg         # City night
├── src/
│   ├── components/
│   │   ├── ImageUploader.jsx      # Drag & drop upload component
│   │   ├── FilterControls.jsx     # Filter toggles and sliders
│   │   ├── FilteredImage.jsx      # Canvas-based image renderer
│   │   └── FilterPreviewGallery.jsx # Filter preset thumbnails
│   ├── App.jsx                 # Main app component
│   ├── App.css                 # Main styles
│   ├── index.css               # Global styles
│   └── main.jsx                # React entry point
├── index.html                  # HTML template
├── package.json                # Dependencies and scripts
├── vite.config.js              # Vite configuration
└── README.md                   # This file
```

## 🎯 How to Use

### 1. Upload an Image

- **Drag and drop** an image onto the upload zone, or
- **Click "Choose File"** to browse your device
- Supported formats: JPG, PNG, GIF, WebP

### 2. Apply Filters

**Style Filters (Toggle On/Off):**
- **Grayscale** - Convert to black and white
- **Sepia** - Add vintage warm tone
- **Invert** - Create negative effect

**Adjustments (Slider Controls):**
- **Brightness** - Make image darker or brighter (0-200%)
- **Contrast** - Adjust contrast levels (0-200%)

### 3. Quick Presets

Choose from 8 pre-configured filter combinations in the preview gallery:
- Original
- B&W (Black and White with enhanced contrast)
- Vintage (Sepia with slight adjustments)
- Bright (Enhanced brightness)
- Dark (Moody low-light effect)
- Negative (Inverted colors)
- Dramatic (High contrast B&W)
- Fade (Low contrast, bright)

### 4. Compare

Hold down the **"Hold to Compare"** button to instantly see the original image vs. your filtered version.

### 5. Download

Click the **"Download Image"** button to save your edited photo as a PNG file.

### 6. Theme Toggle

Click the sun/moon icon in the header to switch between light and dark themes.

## 🛠️ Technical Details

### Key Technologies

- **React 18.2** - Modern React with hooks
- **Vite 5.0** - Lightning-fast build tool
- **HTML5 Canvas** - For image processing and filter application
- **CSS Variables** - Dynamic theming
- **Lucide React** - Beautiful icon library

### Component Architecture

#### App.jsx (Main Container)
- Manages global state for image, filters, and theme
- Coordinates all child components
- Handles file upload, filter changes, and downloads

#### ImageUploader.jsx
- Drag-and-drop file upload
- File input fallback
- Visual upload feedback
- Feature highlights

#### FilterControls.jsx
- Toggle switches for style filters
- Range sliders for brightness/contrast
- Real-time value display
- Reset functionality

#### FilteredImage.jsx
- Canvas-based image rendering
- CSS filter API for real-time effects
- Responsive image scaling
- Maintains aspect ratio

#### FilterPreviewGallery.jsx
- Generates thumbnail previews
- 8 preset filter combinations
- Active state indication
- Click to apply preset

### Filter Implementation

Filters are applied using the CSS `filter` property on the Canvas context:

```javascript
// Example filter string
ctx.filter = 'grayscale(100%) sepia(100%) brightness(140%) contrast(110%)';
```

This approach provides:
- ✅ Real-time performance
- ✅ GPU acceleration
- ✅ No external libraries needed
- ✅ Cross-browser compatibility

## 🚀 Deployment

### Deploy to Vercel (Recommended)

1. **Install Vercel CLI** (if not already installed)
   ```bash
   npm install -g vercel
   ```

2. **Deploy**
   ```bash
   vercel
   ```

3. **Follow the prompts**
   - Confirm project settings
   - Your app will be deployed and you'll get a live URL

### Alternative: Deploy via Vercel Dashboard

1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Click "New Project"
4. Import your GitHub repository
5. Vercel will auto-detect Vite and deploy

### Other Deployment Options

- **Netlify**: Drag and drop the `dist/` folder
- **GitHub Pages**: Use `gh-pages` package
- **Any static host**: Upload the `dist/` folder contents

## 🎨 Customization

### Change Color Scheme

Edit CSS variables in `src/App.css`:

```css
:root {
  --accent-primary: #ff6b9d;      /* Primary accent color */
  --accent-secondary: #4ecdc4;    /* Secondary accent color */
  --bg-primary: #0a0a0f;          /* Main background */
  /* ... more variables */
}
```

### Add New Filter Presets

Edit the `FILTER_PRESETS` array in `src/components/FilterPreviewGallery.jsx`:

```javascript
{
  name: 'My Filter',
  filters: {
    grayscale: false,
    sepia: true,
    invert: false,
    brightness: 120,
    contrast: 95,
  }
}
```

### Modify Fonts

Change fonts in `index.html`:

```html
<link href="https://fonts.googleapis.com/css2?family=YourFont&display=swap" rel="stylesheet">
```

Then update in `src/App.css`:

```css
body {
  font-family: 'YourFont', sans-serif;
}
```

## 📱 Browser Support

- ✅ Chrome/Edge (latest)
- ✅ Firefox (latest)
- ✅ Safari (latest)
- ✅ Mobile browsers (iOS Safari, Chrome Mobile)

## 🤝 Contributing

Feel free to fork, modify, and use this project for your own purposes!

## 📝 License

MIT License - feel free to use this project for personal or commercial purposes.

## 🎓 Learning Resources

This project demonstrates:
- React functional components and hooks (`useState`, `useEffect`, `useRef`)
- File handling and FileReader API
- HTML5 Canvas manipulation
- CSS custom properties for theming
- Responsive design with CSS Grid and Flexbox
- Component composition and prop drilling
- Event handling (drag/drop, mouse, touch)

## 🐛 Troubleshooting

**Issue: App doesn't start**
- Make sure you ran `npm install` first
- Check that you have Node.js 16+ installed: `node --version`

**Issue: Images not uploading**
- Ensure the file is a valid image format (JPG, PNG, GIF, WebP)
- Check browser console for errors

**Issue: Filters not applying**
- Clear browser cache and refresh
- Try a different browser

**Issue: Download not working**
- Check that you've uploaded an image first
- Some browsers may block downloads - allow them in browser settings

## 💡 Tips

- For best results, use high-resolution images
- Experiment with combining multiple filters
- Use the compare button to fine-tune your edits
- Try the sample images in `public/sample-images/` to test features
- Take advantage of keyboard shortcuts (in development mode)

## 🌟 Credits

Built with ❤️ using React and modern web technologies.

Icons by [Lucide](https://lucide.dev)

---

**Enjoy creating beautiful filtered photos!** 📸✨

# 📖 Code Explanation - Photo Filter Studio

This document explains how the code works so you can understand and modify it easily.

## 🏗️ Architecture Overview

```
User Interaction
      ↓
   App.jsx (State Management)
      ↓
  ├── ImageUploader ──→ Handles file upload
  ├── FilterControls ──→ Manages filter UI
  ├── FilteredImage ──→ Renders canvas with filters
  └── FilterPreviewGallery ──→ Shows preset thumbnails
```

## 🧩 Component Breakdown

### 1. App.jsx - The Brain

**What it does**: Main component that manages all state and coordinates child components.

**Key State Variables**:

```javascript
const [image, setImage] = useState(null);
// Stores the uploaded image as base64 string

const [filters, setFilters] = useState({...});
// Stores current filter values:
// - grayscale: boolean
// - sepia: boolean
// - invert: boolean
// - brightness: number (0-200)
// - contrast: number (0-200)

const [showOriginal, setShowOriginal] = useState(false);
// Controls before/after comparison

const [theme, setTheme] = useState('dark');
// Current theme (light/dark)
```

**Key Functions**:

```javascript
handleImageUpload(file)
// Called when user uploads an image
// Reads file and converts to base64
// Resets filters to defaults

handleFilterChange(filterName, value)
// Called when user changes any filter
// Updates the specific filter in state

handleResetFilters()
// Resets all filters to default values

handleDownload()
// Converts canvas to PNG and downloads it
```

**Why it's structured this way**: 
- Central state management makes it easy to coordinate between components
- Pure functions for handlers make testing easier
- Single source of truth for all filter values

---

### 2. ImageUploader.jsx - Upload Handler

**What it does**: Provides drag-and-drop and file input for image upload.

**Key Features**:

```javascript
const [isDragging, setIsDragging] = useState(false);
// Tracks drag state for visual feedback

handleDragOver(e)
// Prevents default and sets dragging state

handleDrop(e)
// Processes dropped file
// Validates it's an image
// Calls parent's onImageUpload callback

handleFileInput(e)
// Processes file from input element
// Calls parent's onImageUpload callback
```

**How drag-and-drop works**:

1. User drags file over zone → `handleDragOver` fires → `isDragging = true`
2. CSS class `dragging` is added → zone changes appearance
3. User drops file → `handleDrop` fires → validates and uploads
4. `isDragging = false` → zone returns to normal

**Visual feedback**: The `.upload-zone.dragging` class makes it clear where to drop.

---

### 3. FilterControls.jsx - Control Panel

**What it does**: Renders toggles and sliders for all filters.

**Component Structure**:

```javascript
// Toggle Filters (Checkboxes styled as switches)
<input type="checkbox" 
       checked={filters.grayscale}
       onChange={(e) => onFilterChange('grayscale', e.target.checked)} />

// Slider Controls
<input type="range"
       min="0" max="200"
       value={filters.brightness}
       onChange={(e) => onFilterChange('brightness', parseInt(e.target.value))} />
```

**CSS Magic - Custom Toggles**:

```css
.toggle-slider {
  /* Creates the switch background */
}

.toggle-slider::before {
  /* Creates the sliding circle */
}

input:checked + .toggle-slider::before {
  transform: translateX(20px);  /* Slides right when on */
}
```

**Why sliders use gradients**: Visual representation of the effect (dark→bright for brightness).

---

### 4. FilteredImage.jsx - The Renderer

**What it does**: Uses HTML5 Canvas to render the image with filters applied.

**How Canvas Filtering Works**:

```javascript
useEffect(() => {
  // 1. Create new Image object
  const img = new Image();
  
  img.onload = () => {
    // 2. Calculate scaled dimensions (maintain aspect ratio)
    let width = img.width;
    let height = img.height;
    // ... scaling logic ...
    
    // 3. Set canvas size
    canvas.width = width;
    canvas.height = height;
    
    // 4. Build CSS filter string
    let filterString = '';
    if (filters.grayscale) filterString += 'grayscale(100%) ';
    if (filters.sepia) filterString += 'sepia(100%) ';
    // ... more filters ...
    
    // 5. Apply filters to canvas context
    ctx.filter = filterString;
    
    // 6. Draw image on canvas
    ctx.drawImage(img, 0, 0, width, height);
  };
  
  img.src = image;  // Triggers loading
}, [image, filters]);  // Re-run when image or filters change
```

**Why use Canvas instead of CSS on `<img>`?**
- Canvas allows us to export the filtered image
- Better cross-browser compatibility
- Can do pixel-level manipulation if needed
- GPU accelerated

**Performance**: The `useEffect` dependency array ensures we only re-render when necessary.

---

### 5. FilterPreviewGallery.jsx - Preset System

**What it does**: Generates thumbnail previews of all filter presets.

**Preset Configuration**:

```javascript
const FILTER_PRESETS = [
  {
    name: 'B&W',
    filters: {
      grayscale: true,
      sepia: false,
      invert: false,
      brightness: 100,
      contrast: 110,
    }
  },
  // ... more presets
];
```

**How Preview Generation Works**:

```javascript
useEffect(() => {
  const img = new Image();
  img.src = image;
  
  img.onload = () => {
    const previewsData = FILTER_PRESETS.map(preset => {
      // Create small canvas (120x120)
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = 120;
      canvas.height = 120;
      
      // Apply preset filters
      ctx.filter = /* build filter string from preset */;
      
      // Draw and crop to square
      ctx.drawImage(img, x, y, scaledWidth, scaledHeight);
      
      // Return data URL for preview
      return {
        name: preset.name,
        dataUrl: canvas.toDataURL(),
        filters: preset.filters
      };
    });
    
    setPreviews(previewsData);
  };
}, [image]);
```

**Why generate previews this way?**
- Shows exact result before applying
- No need to switch back and forth
- Visual comparison of all options
- Lightweight (small canvases)

**Active State Detection**:

```javascript
const isActivePreset = (presetFilters) => {
  return JSON.stringify(presetFilters) === JSON.stringify(currentFilters);
};
```

---

## 🎨 CSS Architecture

### Theme System with CSS Variables

```css
:root {
  --accent-primary: #ff6b9d;
  --bg-primary: #0a0a0f;
  /* ... more variables */
}

[data-theme="light"] {
  --accent-primary: #ff4081;
  --bg-primary: #f8f9fa;
  /* ... overrides */
}

/* Usage */
.button {
  background: var(--accent-primary);
  color: var(--bg-primary);
}
```

**Why CSS variables?**
- Easy theme switching (just change one attribute)
- No JavaScript needed for colors
- Consistent across entire app
- Easy to customize

### Gradient Sliders

```css
.brightness-slider {
  background: linear-gradient(90deg, 
    #1a1a1a 0%,    /* Dark on left */
    #ffd93d 50%,   /* Normal in middle */
    #ffffff 100%   /* Bright on right */
  );
}
```

Visual representation makes it intuitive to understand what the slider does.

### Animation System

```css
@keyframes fadeInSlideUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.feature-card {
  animation: fadeInSlideUp 0.8s ease-out backwards;
}

.feature-card:nth-child(1) { animation-delay: 0.1s; }
.feature-card:nth-child(2) { animation-delay: 0.2s; }
.feature-card:nth-child(3) { animation-delay: 0.3s; }
```

**Staggered animations**: Each card animates slightly after the previous one for a polished feel.

---

## 🔄 Data Flow

### Upload Flow

```
User selects file
    ↓
ImageUploader receives file
    ↓
FileReader converts to base64
    ↓
onImageUpload(base64) callback
    ↓
App.jsx updates image state
    ↓
FilteredImage re-renders with new image
    ↓
FilterPreviewGallery generates previews
```

### Filter Flow

```
User moves slider
    ↓
onChange event fires
    ↓
handleFilterChange(name, value)
    ↓
App.jsx updates filters state
    ↓
FilteredImage useEffect detects change
    ↓
Canvas re-renders with new filters
```

### Download Flow

```
User clicks Download
    ↓
handleDownload() called
    ↓
canvas.toDataURL('image/png')
    ↓
Create temporary <a> element
    ↓
Set href to data URL
    ↓
Trigger click() programmatically
    ↓
Browser downloads file
```

---

## 🛠️ Key React Concepts Used

### 1. useState Hook

```javascript
const [value, setValue] = useState(initialValue);
// value: current state
// setValue: function to update state
// initialValue: starting value
```

**When state updates, React re-renders the component.**

### 2. useEffect Hook

```javascript
useEffect(() => {
  // Code to run
  
  return () => {
    // Cleanup (optional)
  };
}, [dependencies]);
// Re-runs when dependencies change
```

**Used for side effects like drawing on canvas, generating previews.**

### 3. useRef Hook

```javascript
const canvasRef = useRef(null);
// Creates a mutable reference
// Persists between renders
// Used for: <canvas ref={canvasRef} />
```

**Allows parent component to access child's DOM element.**

### 4. Props

```javascript
// Parent
<FilterControls 
  filters={filters}
  onFilterChange={handleFilterChange}
/>

// Child
function FilterControls({ filters, onFilterChange }) {
  // Use props here
}
```

**Data flows down from parent to child via props.**

### 5. Callbacks

```javascript
// Child calls parent's function
onChange={(e) => onFilterChange('brightness', e.target.value)}

// Parent receives the call
const handleFilterChange = (name, value) => {
  setFilters({...filters, [name]: value});
};
```

**Allows child to communicate back to parent.**

---

## 🎯 Advanced Techniques

### 1. Dynamic Filter String Building

```javascript
let filterString = '';

// Conditionally add filters
if (filters.grayscale) filterString += 'grayscale(100%) ';
if (filters.sepia) filterString += 'sepia(100%) ';
if (filters.invert) filterString += 'invert(100%) ';

// Always add these
filterString += `brightness(${filters.brightness}%) `;
filterString += `contrast(${filters.contrast}%) `;

// Result: "grayscale(100%) brightness(120%) contrast(110%)"
```

### 2. Aspect Ratio Preservation

```javascript
const aspectRatio = img.width / img.height;

if (width > maxWidth) {
  width = maxWidth;
  height = width / aspectRatio;  // Maintain ratio
}

if (height > maxHeight) {
  height = maxHeight;
  width = height * aspectRatio;  // Maintain ratio
}
```

### 3. Data URL for Download

```javascript
const dataUrl = canvas.toDataURL('image/png');
// Returns: "data:image/png;base64,iVBORw0KGgo..."

const link = document.createElement('a');
link.href = dataUrl;
link.download = 'filename.png';
link.click();  // Triggers browser download
```

### 4. Theme Detection and Application

```javascript
useEffect(() => {
  document.documentElement.setAttribute('data-theme', theme);
}, [theme]);

// HTML becomes: <html data-theme="dark">
// CSS can target: [data-theme="dark"] { ... }
```

---

## 📝 Modification Guide

### Add a New Filter

1. **Add to state** (App.jsx):
```javascript
const [filters, setFilters] = useState({
  // ... existing filters
  blur: 0,  // NEW FILTER
});
```

2. **Add control** (FilterControls.jsx):
```javascript
<input type="range" min="0" max="10"
       value={filters.blur}
       onChange={(e) => onFilterChange('blur', parseInt(e.target.value))} />
```

3. **Apply in canvas** (FilteredImage.jsx):
```javascript
filterString += `blur(${filters.blur}px) `;
```

### Add a New Preset

Edit `FILTER_PRESETS` in FilterPreviewGallery.jsx:

```javascript
{
  name: 'Dreamy',
  filters: {
    grayscale: false,
    sepia: false,
    invert: false,
    brightness: 110,
    contrast: 85,
    blur: 2,  // If you added blur
  }
}
```

### Change Color Scheme

Edit CSS variables in App.css:

```css
:root {
  --accent-primary: #your-color;
  --bg-primary: #your-color;
}
```

---

## 🧪 Testing Tips

### Manual Testing Checklist

- [ ] Upload different image formats (JPG, PNG, GIF)
- [ ] Test drag and drop
- [ ] Try each filter individually
- [ ] Test slider extremes (0 and 200)
- [ ] Combine multiple filters
- [ ] Test before/after comparison
- [ ] Try each preset
- [ ] Download and verify image quality
- [ ] Switch themes
- [ ] Test on mobile device
- [ ] Test with large images (5000x5000px)

### Common Debug Techniques

```javascript
// See what's in state
console.log('Current filters:', filters);

// Check if function is called
const handleFilterChange = (name, value) => {
  console.log('Filter changed:', name, value);
  // ...
};

// Inspect canvas
console.log('Canvas dimensions:', canvas.width, canvas.height);
console.log('Filter string:', filterString);
```

---

## 🎓 Learning Exercises

Try these to deepen your understanding:

1. **Add a rotation filter** (hint: CSS `rotate()`)
2. **Add saturation control** (hint: CSS `saturate()`)
3. **Create a "before/after split view"** instead of toggle
4. **Add undo/redo functionality** (hint: keep history array)
5. **Add image cropping** (hint: canvas.drawImage with crop params)
6. **Save settings to localStorage** (hint: localStorage.setItem)
7. **Add keyboard shortcuts** (hint: useEffect with keydown listener)
8. **Create shareable preset URLs** (hint: URL params)

---

**Now you understand how everything works! Happy coding! 🚀**
